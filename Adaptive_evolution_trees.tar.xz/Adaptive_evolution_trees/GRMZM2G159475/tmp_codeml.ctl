seqfile = transAln_cds_300_GRMZM2G159475.nt_cleanali.fasta
treefile = gene.raxml.bestTree
outfile = results_GRMZM2G159475.txt

